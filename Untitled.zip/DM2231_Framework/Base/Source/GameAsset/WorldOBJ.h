#pragma once
#include "GameObject.h"

class CWorldOBJ : public CGameObject
{
public:
	CWorldOBJ();
	~CWorldOBJ();

	int id;
};

