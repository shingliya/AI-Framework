#include "WorldOBJ.h"



CWorldOBJ::CWorldOBJ()
{
	type = STATIC_OBJ;
	id = -1;
}


CWorldOBJ::~CWorldOBJ()
{
}